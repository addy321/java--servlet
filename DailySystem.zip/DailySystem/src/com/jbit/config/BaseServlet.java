package com.jbit.config;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class BaseServlet extends HttpServlet {

	/**
	 * 封装 Servlet
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
		resp.setCharacterEncoding("UTF-8");
        String name = req.getParameter("method");//获取方法名
    //其中method可以是可以任意取得，如getParameter("service")等
        if(name == null || name.isEmpty()){
            throw new RuntimeException("method parameter does not exist");
        }
        Class<? extends BaseServlet> c = this.getClass();//获得当前类的Class对象
        Method method = null;
        try {
            //获得Method对象
        	System.out.println("跳转=====>"+name);
            method =  c.getMethod(name,HttpServletRequest.class,HttpServletResponse.class);
        } catch (Exception e) {
        }
        try {
            method.invoke(this, req,resp);//反射调用方法
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
	
	public void showView(String path,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher(path).forward(request, response);
	}

}
