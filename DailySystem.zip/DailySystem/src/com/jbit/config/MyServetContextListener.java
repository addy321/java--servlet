package com.jbit.config;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MyServetContextListener implements ServletContextListener,HttpSessionListener,HttpSessionAttributeListener {

	 //web应用关闭时调用该方法
    @Override
    public void contextDestroyed(ServletContextEvent event) {
        System.out.println("关闭应用");
    }

    //web应用启动时调用该方法
    @Override
    public void contextInitialized(ServletContextEvent event) {  
        System.out.println("启动应用");
    }

	@Override
	public void attributeAdded(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("attributeAdded......................");
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("attributeRemoved....................");
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("attributeReplaced.............");
	}

	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		HttpSession session = arg0.getSession();
        String sessionId = session.getId();
        System.out.println("建立了会话，会话ID为："+sessionId);
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("sessionDestroyed...............");
		
	}
	

}
