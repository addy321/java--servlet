package com.jbit.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jbit.config.BaseServlet;
import com.jbit.entity.User;
import com.jbit.service.UserService;

/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/Account")
public class AccountServlet extends BaseServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void showLogin(HttpServletRequest request, HttpServletResponse response) {
        //登陆跳转
		try {
			showView("login.jsp", request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
    }
	
	public void login(HttpServletRequest request, HttpServletResponse response) {
      //登陆的方法
  		try {
  			String username=request.getParameter("userName");
  	        String password=request.getParameter("password");
  	        System.out.println("登录账号=====>"+username);
  	        System.out.println("登录密码=====>"+password);
  	        boolean isrequest = false;
  	        String returnText = "";
  	        if(username == null || username.trim().equals("")) {
  	        	returnText = "登录账号不能为空";
  	        }else if(password == null || password.trim().equals("")) {
  	        	returnText = "登录密码不能为空";
			}else {
				Object[] params = new Object[] {username};
				List<Object> dataList = UserService.queryUser("select * from user where userName=?", params);
				if(dataList.size()>0) {
					Object object =dataList.get(0);
					System.out.println("查询的会员信息："+object);
					request.getSession().setAttribute("loginName", username);
					isrequest = true;
					UserService.upUserisOnline(params);
				}else {
					returnText = "没有查询到该会员的信息";
				}
			}
  	        request.setAttribute("error",returnText);
  	        if(isrequest) {
  	        	response.sendRedirect("Admin?method=userList");
  	        }else {
  	        	showView("login.jsp", request, response);
			}
  		} catch (ServletException | IOException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
    }
	
}
