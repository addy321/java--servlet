package com.jbit.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jbit.config.BaseServlet;
import com.jbit.service.ScheduleService;
import com.jbit.service.UserService;

@WebServlet("/Admin")
public class AdminService extends BaseServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void userForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			String userId=request.getParameter("userId");
			System.out.println("用户id=====>"+userId);
			if(userId == null || userId.trim().equals("")) {
				showView("userForm.jsp", request, response);
			}else {
				Object[] params = new Object[] {userId};
				List<Object> dataList = UserService.queryUser("select * from user where id=?", params);
				System.out.println("dataList==>"+dataList.toString());
				request.setAttribute("user", dataList.get(0));
				showView("userForm.jsp", request, response);
			}
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public void userList(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Object> dataList = UserService.queryUser("select * from user", null);
			int total = UserService.getUserCount();
			System.out.println("dataList=====>"+dataList.toString());
			System.out.println("total=====>"+total);
        	request.setAttribute("Users",dataList);
        	request.setAttribute("total",total);
        	showView("user.jsp", request, response);
		}  catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public void delUser(HttpServletRequest request, HttpServletResponse response) {
		try {
			String userId=request.getParameter("userId");
			System.out.println("用户id=====>"+userId);
			if(userId == null || userId.trim().equals("")) {
				showView("user.jsp", request, response);
			}else {
				UserService.delUser(new Object[] {userId});
				List<Object> dataList = UserService.queryUser("select * from user", null);
	        	request.setAttribute("Users",dataList);
	        	showView("user.jsp", request, response);
			}
		}  catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public void saveUser(HttpServletRequest request, HttpServletResponse response) {
		try {
			String userId=request.getParameter("id");
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			String nickname=request.getParameter("nickname");
			String isOnline=request.getParameter("isOnline");
			String status=request.getParameter("status").trim();
			System.out.println("userId=====>"+userId);
			System.out.println("userName=====>"+userName);
			System.out.println("password=====>"+password);
			System.out.println("nickname=====>"+nickname);
			System.out.println("isOnline=====>"+isOnline);
			System.out.println("status=====>"+status);
			if(userId == null || userId.trim().equals("")) {
				UserService.addUser(new Object[] {userName,password,nickname,isOnline,status});
			}else {
				UserService.upUser(new Object[] {password,nickname,isOnline,status,userId});
			}
			response.sendRedirect("Admin?method=userList");
		}  catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void dailyList(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Object> dataList = ScheduleService.querySchedule("select * from schedule", null);
			int totla = ScheduleService.getCount();
			System.out.println("dataList=====>"+dataList.toString());
			System.out.println("totla=====>"+totla);
        	request.setAttribute("schedules",dataList);
        	request.setAttribute("totla",totla);
        	showView("schedule.jsp", request, response);
		}  catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	public void scheduleForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id=request.getParameter("Id");
			System.out.println("日程id=====>"+id);
			if(id == null || id.trim().equals("")) {
				showView("scheduleForm.jsp", request, response);
			}else {
				Object[] params = new Object[] {id};
				List<Object> dataList = ScheduleService.querySchedule("select * from schedule where id=?", params);
				System.out.println("dataList==>"+dataList.toString());
				request.setAttribute("schedule", dataList.get(0));
				showView("scheduleForm.jsp", request, response);
			}
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	public void delSchedule(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id=request.getParameter("Id");
			System.out.println("日程id=====>"+id);
			if(id == null || id.trim().equals("")) {
				showView("schedule.jsp", request, response);
			}else {
				ScheduleService.delSchedule(new Object[] {id});
				response.sendRedirect("Admin?method=dailyList");
			}
		}  catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	public void saveSchedule(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id=request.getParameter("id");
			String userName=request.getParameter("userName");
			String executionTime=request.getParameter("executionTime");
			String executionContent=request.getParameter("executionContent");
			System.out.println("id=====>"+id);
			System.out.println("userName=====>"+userName);
			System.out.println("executionTime=====>"+executionTime);
			System.out.println("executionContent=====>"+executionContent);
			if(id == null || id.trim().equals("")) {
				ScheduleService.addSchedule(new Object[] {userName,executionTime,executionContent});
			}else {
				ScheduleService.upSchedule(new Object[] {userName,executionTime,executionContent});
			}
			response.sendRedirect("Admin?method=dailyList");
		}  catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
