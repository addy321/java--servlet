package com.jbit.entity;

import java.util.Date;

public class Schedule {
	private int id;
	private String userName;
	private Date executionTime;
	private String executionContent;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(Date executionTime) {
		this.executionTime = executionTime;
	}
	public String getExecutionContent() {
		return executionContent;
	}
	public void setExecutionContent(String executionContent) {
		this.executionContent = executionContent;
	}
	@Override
	public String toString() {
		return "Schedule [id=" + id + ", userName=" + userName + ", executionTime=" + executionTime
				+ ", executionContent=" + executionContent + "]";
	}
}
