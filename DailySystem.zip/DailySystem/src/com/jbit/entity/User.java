package com.jbit.entity;

public class User {

	private int id;
	private String userName;
	private String password;
	private String nickname;
	private int isOnline;
	private int status;
	public User(int id, String userName, String password, String nickname, int isOnline, int status) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.nickname = nickname;
		this.isOnline = isOnline;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public int getIsOnline() {
		return isOnline;
	}
	public void setIsOnline(int isOnline) {
		this.isOnline = isOnline;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", password=" + password + ", nickname=" + nickname
				+ ", isOnline=" + isOnline + ", status=" + status + "]";
	}
	
}
