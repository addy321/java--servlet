package com.jbit.service;

import java.util.List;

import com.jbit.config.DBHelper;

public class ScheduleService {
	private static DBHelper db = null;
	
	public static List<Object> querySchedule(String sql,Object[] params) {
		db = new DBHelper();
        return db.query(sql, params);
    }
	
	public static int delSchedule(Object[] params) {
		db = new DBHelper();
		return db.update("delete from schedule where id=?", params);
	}
	public static int addSchedule(Object[] params) {
		db = new DBHelper();
		return db.update("insert into schedule(userName,executionTime,executionContent)values(?,?,?)", params);
	}
	public static int upSchedule(Object[] params) {
		db = new DBHelper();
		return db.update("update schedule set userName=?,executionTime=?,executionContent=? where id = ?", params);
	}
	
	public static int getCount() {
		db = new DBHelper();
		int totle = db.getCount("select count(1) from schedule");
		return totle;
	}
}
