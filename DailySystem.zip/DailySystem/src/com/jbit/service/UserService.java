package com.jbit.service;

import java.util.List;

import com.jbit.config.DBHelper;

public class UserService {
	/**
	 * 查询会员集合
	 * @param sql
	 * @param params
	 * @return
	 */
	private static DBHelper db = null;
	public static List<Object> queryUser(String sql,Object[] params) {
		db = new DBHelper();
        return db.query(sql, params);
    }
	
	public static int upUserisOnline(Object[] params) {
		db = new DBHelper();
		return db.update("update user set isOnline=1 where userName=?", params);
	}
	public static int delUser(Object[] params) {
		db = new DBHelper();
		return db.update("delete from user where id=?", params);
	}
	public static int addUser(Object[] params) {
		db = new DBHelper();
		return db.update("insert into user(userName,password,nickname,isOnline,status)values(?,?,?,?,?)", params);
	}
	public static int upUser(Object[] params) {
		db = new DBHelper();
		return db.update("update user set password=?,nickname=?,isOnline=?,status=? where id = ?", params);
	}
	public static int getUserCount() {
		db = new DBHelper();
		return db.getCount("select count(1) from user where isOnline = 1");
	}
}
